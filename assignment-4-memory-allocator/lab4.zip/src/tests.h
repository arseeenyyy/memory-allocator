#ifndef TESTS_H
#define TESTS_H

int test1();
int test2(); 
int test3(); 
int test4();
int test5();

#endif